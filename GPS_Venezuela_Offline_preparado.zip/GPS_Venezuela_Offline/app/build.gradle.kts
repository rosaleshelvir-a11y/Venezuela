plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gpsvenezuela.offline"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gpsvenezuela.offline"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
