package com.gpsvenezuela.offline

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity(), LocationListener, TextToSpeech.OnInitListener {
    private lateinit var locationManager: LocationManager
    private lateinit var status: TextView
    private lateinit var coords: TextView
    private lateinit var direction: TextView
    private lateinit var speed: TextView
    private lateinit var accuracy: TextView
    private lateinit var recordButton: Button
    private lateinit var markButton: Button
    private var recording = false
    private var tts: TextToSpeech? = null
    private var lastSpokenDirection = ""
    private var lastLocation: Location? = null
    private var trackFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        tts = TextToSpeech(this, this)
        buildScreen()
        if (hasLocationPermission()) startGps() else requestPermissions(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 41
        )
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 34, 28, 24)
            setBackgroundColor(0xFFF4F6F8.toInt())
        }
        fun label(value: String, size: Float, bold: Boolean = false): TextView = TextView(this).apply {
            text = value; textSize = size; gravity = Gravity.CENTER
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF17212B.toInt()); setPadding(4, 10, 4, 10)
        }
        root.addView(label("GPS VENEZUELA OFFLINE", 23f, true))
        status = label("Buscando señal de satélites…", 16f)
        root.addView(status)
        coords = label("Ubicación: esperando GPS", 18f, true); root.addView(coords)
        direction = label("Dirección: —", 25f, true); root.addView(direction)
        speed = label("Velocidad: —", 18f); root.addView(speed)
        accuracy = label("Precisión: —", 16f); root.addView(accuracy)
        val note = label("Esta primera versión registra tu recorrido. Todavía no incluye mapa de carreteras ni cálculo de rutas.", 14f)
        root.addView(note)
        recordButton = Button(this).apply { text = "INICIAR GRABACIÓN"; textSize = 17f; setOnClickListener { toggleRecording() } }
        root.addView(recordButton, LinearLayout.LayoutParams(-1, -2))
        markButton = Button(this).apply { text = "MARCAR CRUCE / REFERENCIA"; isEnabled = false; setOnClickListener { markPoint() } }
        root.addView(markButton, LinearLayout.LayoutParams(-1, -2))
        val stop = Button(this).apply { text = "CENTRAR GPS / ACTUALIZAR"; setOnClickListener { startGps() } }
        root.addView(stop, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun hasLocationPermission() = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startGps() {
        if (!hasLocationPermission()) return
        try {
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                status.text = "Activa Ubicación/GPS en los ajustes del teléfono"; return
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500L, 2f, this, Looper.getMainLooper())
            status.text = "GPS activo · No necesita datos móviles"
            @Suppress("MissingPermission")
            locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { onLocationChanged(it) }
        } catch (e: Exception) { status.text = "No se pudo iniciar GPS: ${e.localizedMessage}" }
    }

    override fun onLocationChanged(location: Location) {
        lastLocation = location
        coords.text = "Latitud: ${"%.5f".format(Locale.US, location.latitude)}\nLongitud: ${"%.5f".format(Locale.US, location.longitude)}"
        val bearing = if (location.hasBearing()) location.bearing else Float.NaN
        val cardinal = if (bearing.isNaN()) "Quieto / calculando" else cardinal(bearing)
        direction.text = "Dirección: $cardinal${if (!bearing.isNaN()) " (${bearing.roundToInt()}°)" else ""}"
        speed.text = "Velocidad: ${if (location.hasSpeed()) "%.0f km/h".format(Locale.US, location.speed * 3.6f) else "—"}"
        accuracy.text = "Precisión GPS: ${if (location.hasAccuracy()) "±${location.accuracy.roundToInt()} m" else "calculando"}"
        status.text = "GPS conectado · ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}"
        if (recording) writePoint(location, "PUNTO")
        if (recording && cardinal != "Quieto / calculando" && cardinal != lastSpokenDirection) {
            lastSpokenDirection = cardinal
            tts?.speak("Rumbo $cardinal", TextToSpeech.QUEUE_FLUSH, null, "bearing")
        }
    }

    private fun cardinal(degrees: Float): String {
        val dirs = arrayOf("Norte", "Noreste", "Este", "Sureste", "Sur", "Suroeste", "Oeste", "Noroeste")
        return dirs[((degrees + 22.5f) / 45f).toInt() % 8]
    }

    private fun toggleRecording() {
        if (!hasLocationPermission()) { requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 41); return }
        recording = !recording
        if (recording) {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            trackFile = File(getExternalFilesDir(null), "Recorrido_$stamp.csv")
            trackFile?.writeText("tipo,fecha_hora,latitud,longitud,velocidad_kmh,rumbo_grados,precision_m\n")
            recordButton.text = "DETENER GRABACIÓN"; markButton.isEnabled = true
            status.text = "Grabando recorrido · ${trackFile?.name}"
            lastSpokenDirection = ""
            lastLocation?.let { writePoint(it, "INICIO") }
        } else {
            recordButton.text = "INICIAR GRABACIÓN"; markButton.isEnabled = false
            status.text = "Recorrido guardado en archivos de la aplicación"
            Toast.makeText(this, "Recorrido guardado", Toast.LENGTH_LONG).show()
        }
    }

    private fun writePoint(location: Location, type: String) {
        val file = trackFile ?: return
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(location.time))
        val row = listOf(type, time, location.latitude, location.longitude,
            if (location.hasSpeed()) location.speed * 3.6f else 0f,
            if (location.hasBearing()) location.bearing else -1f,
            if (location.hasAccuracy()) location.accuracy else -1f).joinToString(",")
        file.appendText(row + "\n")
    }

    private fun markPoint() {
        val loc = lastLocation
        if (loc == null) { Toast.makeText(this, "Esperando ubicación GPS", Toast.LENGTH_SHORT).show(); return }
        writePoint(loc, "CRUCE_O_REFERENCIA")
        Toast.makeText(this, "Referencia guardada", Toast.LENGTH_SHORT).show()
    }

    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale("es", "VE") }
    override fun onProviderEnabled(provider: String) { status.text = "GPS activado" }
    override fun onProviderDisabled(provider: String) { status.text = "GPS desactivado. Activa Ubicación." }
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && hasLocationPermission()) startGps()
        else status.text = "Necesitamos permiso de ubicación para usar el GPS"
    }

    override fun onDestroy() {
        try { locationManager.removeUpdates(this) } catch (_: Exception) {}
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
